# SETI / LS7C – færdigt resultat, afventer offentliggørelse

12. september 2026. Alle 1.300 forsøg er afsluttet på de samme ti TESS-baggrunde.

- Genfinding af enkeltpulser på 1%: 22/60 med den nye billedtest mod 5/60 med den gamle.
- Metoden består stadig ikke: 6/20 enkeltpixel-fejl slipper igennem ved screeningsscore 9, og baggrundstesten afviser nogle kraftige stjernepulser.
- Ingen ny SETI-kandidat. Ingen ny TESS-sektor er åbnet.
- 22 kontroltests og integritetskontrollen består; gamle resultater er bevaret.

Læs science/results_ls7c_tess/REVIEW.md for fortolkningen og REPORT.md for alle tabeller.
Diagrammet ligger samme sted som comparison.png og comparison.svg.

Automatisk godkendelseskontrol afviste GitHub-upload to gange. Den accepterede
ikke den løbende tilladelse fra samtalehistorikken. Derfor er intet LS7C-materiale
offentliggjort. Før forsøget blev metoden fastlåst i en lokal Git-commit.

Pakken er klar til konkret godkendelse af offentliggørelse af LS7C-kode,
forsøgsplan, forsøgsdata, figurer, rapporter og dokumentation til
andersenmartin-blip/setisearch på m43-support-qualification samt README på main.

## Gendannelse

science/ indeholder præcis de 35 nye eller ændrede filer til forskningsgrenen.
main/README.md er den forberedte README; original og patch ligger ved siden af.
publication_manifest.json angiver commits, destinationer og alle filhashes.
setisearch_LS7C.bundle indeholder begge lokale forskningscommits med den
allerede offentlige base som forudsætning. Et eksisterende clone kan læse
bundlen med git fetch. Recheck altid aktuelle remote heads før offentliggørelse.

SHA256SUMS verificerer alle pakkefiler. De oprindelige forsøgs- og reviewdata
har desuden egne checksum-manifester. Rå FITS-filer hentes ved behov via de
uændrede offentlige LS7B-kildehenvisninger; de indgår ikke i denne pakke.
