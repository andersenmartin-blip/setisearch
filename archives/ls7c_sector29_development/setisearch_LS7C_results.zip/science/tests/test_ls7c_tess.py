import json
from pathlib import Path
import unittest

import numpy as np

from seti_repeater.light_sail_tess_v2 import match_trial, shifted_profile
from seti_repeater.light_sail_tess_v3 import (
    fit_profile_bank, mean_difference_variance, noise_aware_pixel,
    solve_aperture_amplitude, spatial_patterns,
)

ROOT = Path(__file__).resolve().parents[1]
CFG = json.loads((ROOT / "config/ls7c_tess_development.json").read_text())
BASE = json.loads((ROOT / CFG["source_config"]).read_text())


class NoiseAwareImages(unittest.TestCase):
    def setUp(self):
        self.ap = np.zeros((7, 7), bool)
        self.ap[2:5, 2:5] = True
        self.profile = np.zeros((7, 7))
        self.profile[self.ap] = np.array([1, 2, 1, 2, 4, 2, 1, 2, 1]) / 16
        self.cube = np.random.default_rng(71303).normal(size=(401, 7, 7))
        self.cube += 20000 * self.profile + 5

    def test_analytic_weighted_fit_and_scale_invariance(self):
        # Equal two-pixel template: information = .25*(1+.25), A = 5.6.
        fit = fit_profile_bank([2, 6], [1, 4], [[.5, .5]])
        self.assertAlmostEqual(fit["amplitude_e_per_s"], 5.6)
        self.assertAlmostEqual(fit["q"], 3.2)
        scaled = fit_profile_bank([20, 60], [100, 400], [[.5, .5]])
        self.assertAlmostEqual(scaled["q"], fit["q"])
        self.assertAlmostEqual(scaled["amplitude_score"], fit["amplitude_score"])
        self.assertEqual(fit_profile_bank([-2, -6], [1, 4], [[.5, .5]])["amplitude_e_per_s"], 0)

    def test_noisy_pixel_does_not_dominate_residual(self):
        delta = [10, 10, 100]
        self.assertLess(fit_profile_bank(delta, [1, 1, 10000], [[1/3]*3])["q"], 1)
        self.assertGreater(fit_profile_bank(delta, [1, 1, 1], [[1/3]*3])["q"], 1000)
        with self.assertRaises(ValueError):
            fit_profile_bank(delta, [1, 0, 1], [[1/3]*3])

    def test_temporal_correlations_raise_variance(self):
        rng = np.random.default_rng(77441)
        sides = [np.repeat(rng.normal(size=1000), 5)[:, None] for _ in range(2)]
        variance = mean_difference_variance(*sides, 5)[0]
        self.assertGreater(variance, .7)
        self.assertLess(variance, 1.4)

    def test_source_and_off_grid_profile_pass_but_concentrated_excess_fails(self):
        for displacement in ([0, 0], [.2, 0]):
            injected = self.cube.copy()
            injected[199:202] += 100 * shifted_profile(self.profile, self.ap, displacement)
            self.assertTrue(noise_aware_pixel(injected, self.ap, 199, 202, CFG["pixel_rule"])["pass"])
        injected = self.cube.copy()
        injected[199:202, 3, 3] += 100
        result = noise_aware_pixel(injected, self.ap, 199, 202, CFG["pixel_rule"])
        self.assertFalse(result["pass"])
        self.assertIn("spatial_residual", result["reasons"])

    def test_uniform_background_and_invalid_data_fail(self):
        injected = self.cube.copy()
        injected[199:202] += 10
        result = noise_aware_pixel(injected, self.ap, 199, 202, CFG["pixel_rule"])
        self.assertFalse(result["pass"])
        self.assertIn("outside_background", result["reasons"])
        injected[200, 3, 3] = np.nan
        self.assertFalse(noise_aware_pixel(injected, self.ap, 199, 202, CFG["pixel_rule"])["pass"])
        self.assertFalse(noise_aware_pixel(self.cube, self.ap, 4, 6, CFG["pixel_rule"])["pass"])

    def test_all_modes_preserve_aperture_light_curve(self):
        patterns = spatial_patterns(np.median(self.cube, axis=0), self.ap, CFG)
        self.assertEqual(len(patterns), 11)
        seconds = (np.arange(401) - 200) * 20
        pulse = np.zeros(401)
        pulse[199:202] = [.25, 1, .25]
        native = self.cube[:, self.ap].sum(axis=1)
        for _, _, pattern, _ in patterns:
            self.assertAlmostEqual(float(pattern[self.ap].sum()), 1, places=12)
            modified = (self.cube + 100 * pulse[:, None, None] * pattern)[:, self.ap].sum(axis=1)
            np.testing.assert_allclose(modified, native + 100 * pulse, rtol=0, atol=1e-9)

    def test_target_score_solver_and_matched_windows(self):
        seconds = (np.arange(401) - 200) * 20
        pulse = np.zeros(401)
        pulse[199:202] = [.25, 1, .25]
        native = self.cube[:, self.ap].sum(axis=1)
        amp, best, confounded = solve_aperture_amplitude(native, pulse, seconds, [0], 3, BASE, 12, 36)
        self.assertFalse(confounded)
        self.assertAlmostEqual(best["score"], 12, places=6)
        for _, _, pattern, _ in spatial_patterns(np.median(self.cube, axis=0), self.ap, CFG):
            modified = (self.cube + amp * pulse[:, None, None] * pattern)[:, self.ap].sum(axis=1)
            actual, _ = match_trial(native, modified, seconds, [0], 3, BASE)
            self.assertEqual((actual["start"], actual["stop"]), (best["start"], best["stop"]))
            self.assertAlmostEqual(actual["score"], best["score"], places=7)


if __name__ == "__main__":
    unittest.main()
