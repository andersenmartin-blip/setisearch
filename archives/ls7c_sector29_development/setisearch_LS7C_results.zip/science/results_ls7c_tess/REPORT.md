# LS7C: noise-aware TESS image comparison

12 September 2026. **Closed-data development checks: FAIL.**

All 1,300 digital trials completed on the same ten LS7B sector 29 backgrounds. No new sector was opened. This is method development, not independent detector qualification or new sky coverage.

## Amplitude-grid recovery

Old and new image rules use exactly the same temporal scores and event windows. Counts below are conditional digital recoveries after both stages.

| Shape | Added aperture light | Reaches screen | Old recovery | New recovery | Trials |
|---|---:|---:|---:|---:|---:|
| box100 | 0.1% | 0 | 0 | 0 | 20 |
| box100 | 0.3% | 0 | 0 | 0 | 20 |
| box100 | 1% | 16 | 3 | 13 | 20 |
| box100 | 3% | 20 | 19 | 17 | 20 |
| box100 | 10% | 20 | 20 | 17 | 20 |
| box30 | 0.1% | 0 | 0 | 0 | 20 |
| box30 | 0.3% | 0 | 0 | 0 | 20 |
| box30 | 1% | 0 | 0 | 0 | 20 |
| box30 | 3% | 20 | 9 | 17 | 20 |
| box30 | 10% | 20 | 20 | 17 | 20 |
| box60 | 0.1% | 0 | 0 | 0 | 20 |
| box60 | 0.3% | 0 | 0 | 0 | 20 |
| box60 | 1% | 9 | 2 | 9 | 20 |
| box60 | 3% | 20 | 10 | 18 | 20 |
| box60 | 10% | 20 | 20 | 16 | 20 |
| doublet30sep87 | 0.1% | 0 | 0 | 0 | 20 |
| doublet30sep87 | 0.3% | 0 | 0 | 0 | 20 |
| doublet30sep87 | 1% | 0 | 0 | 0 | 20 |
| doublet30sep87 | 3% | 20 | 14 | 20 | 20 |
| doublet30sep87 | 10% | 20 | 19 | 20 | 20 |

## Challenges with identical aperture light curves

Every matched case reaches screening. Centered stars, shifted stars and nuisances have the same best temporal window and score in their matched group. Nuisance acceptance therefore tests the spatial rule above threshold.

| Score | Pattern | Old accepted | New accepted | Trials |
|---:|---|---:|---:|---:|
| 9 | off_profile | 20 | 68 | 80 |
| 9 | pointing_mode | 0 | 0 | 80 |
| 9 | single_pixel | 0 | 6 | 20 |
| 9 | stellar | 5 | 17 | 20 |
| 9 | uniform | 0 | 0 | 20 |
| 12 | off_profile | 26 | 68 | 80 |
| 12 | pointing_mode | 0 | 0 | 80 |
| 12 | single_pixel | 0 | 1 | 20 |
| 12 | stellar | 8 | 17 | 20 |
| 12 | uniform | 0 | 0 | 20 |
| 20 | off_profile | 39 | 68 | 80 |
| 20 | pointing_mode | 0 | 0 | 80 |
| 20 | single_pixel | 0 | 0 | 20 |
| 20 | stellar | 11 | 17 | 20 |
| 20 | uniform | 0 | 0 | 20 |
| 40 | off_profile | 66 | 68 | 80 |
| 40 | pointing_mode | 0 | 0 | 80 |
| 40 | single_pixel | 0 | 0 | 20 |
| 40 | stellar | 19 | 17 | 20 |
| 40 | uniform | 0 | 0 | 20 |

## Fixed checks

| Check | Result |
|---|---|
| single_recovery_0.03 | FAIL |
| single_recovery_0.1 | FAIL |
| stellar_score_9 | FAIL |
| off_profile_score_9 | FAIL |
| single_pixel_score_9 | FAIL |
| uniform_score_9 | PASS |
| pointing_mode_score_9 | PASS |
| stellar_score_12 | FAIL |
| off_profile_score_12 | FAIL |
| single_pixel_score_12 | PASS |
| uniform_score_12 | PASS |
| pointing_mode_score_12 | PASS |
| stellar_score_20 | FAIL |
| off_profile_score_20 | FAIL |
| single_pixel_score_20 | PASS |
| uniform_score_20 | PASS |
| pointing_mode_score_20 | PASS |
| stellar_score_40 | FAIL |
| off_profile_score_40 | FAIL |
| single_pixel_score_40 | PASS |
| uniform_score_40 | PASS |
| pointing_mode_score_40 | PASS |
| all_matched_reach_screen | PASS |
| exact_matching | PASS |
| unchanged_controls | PASS |
| no_baseline_confounding | PASS |
| complete_trials | PASS |

## Native and integrity diagnostics

The new image rule passes 16/343 previously sealed native windows. All old windows and their old measurements are preserved. These are retrospective diagnostics, not promoted candidates. None of the original windows reaches threshold on the corrected stream with the original noise scale.

The 240 overlapping stellar cases reproduce the original LS7B windows, scores and old classifications. LS7B's 5/60 recovery at 1% remains its original result. [Audit](AUDIT.json).

## Interpretation and continuation

See [REVIEW.md](REVIEW.md) for interpretation of the complete fixed result and the next concrete step. The checks cannot establish independent qualification even if all pass. No rule is adopted for a sky survey in this development run.

The image model uses empirical diagonal pixel noise and a small shifted-profile bank. The residual reference cut is not a calibrated probability. Trials share ten backgrounds; no independent-trial confidence interval is inferred. Source injections add deterministic light without additional photon noise and occur after mission processing. Stellar flares and unresolved astrophysical sources remain possible passes.

Normalized signed pointing modes are deliberately amplified spatial stress patterns. They do not represent literal translations with a measured physical occurrence rate. Their signed scales, fractional pixel changes and negative modeled scene counts are in the ledgers.

[Comparison figure](comparison.svg), [machine-readable summary](summary.json), [input identities](provenance.json), [protocol](../LS7C_TESS_DEVELOPMENT_PROTOCOL.md), [output checksums](SHA256SUMS).

Per-anchor and native-part `*.jsonl.gz` files are ordinary deterministic gzip JSONL. Read with Python's gzip module. Run the `--audit` command in the protocol to verify full membership and decision accounting.

Scientific code commit: `27709b72be76f260be10f3d85239eddef575937a`. Freeze SHA-256: `931d6cffd32f17cf4cd9713b152a1a39c25e22e6f319befe02431bb30068c45e`.
