# LS7C reviewed result: weak-signal gains, new failure modes

12 September 2026. **The noise-aware image rule fails the fixed development
checks.** All 1,300 trials completed; none of the detector settings was changed
after this run. This is a useful diagnosis on the already opened sector 29,
not independent validation or an adopted optical SETI detector.

## What changed in recovery

The temporal screen is unchanged. The new image comparison uses empirical
pixel noise and a small bank of shifted stellar profiles instead of a hard
cosine/centroid cut. The comparison uses the exact same injected signals.

| Added light, single pulses | Reaches screen | Old full recovery | New full recovery |
|---|---:|---:|---:|
| 1% | 25/60 | 5/60 | **22/60** |
| 3% | 60/60 | 38/60 | **52/60** |
| 10% | 60/60 | 60/60 | **50/60** |

At 1%, 35 cases still fail the unchanged temporal screen, while only three
above-threshold cases are lost by the new image rule. The new rule therefore
addresses much of the original weak-image loss. The 30-second 1% pulses still
all fall below temporal threshold; this change cannot recover them.

The stronger trials expose a regression: the old rule recovers every 10%
single pulse, while the new rule loses ten. Recovery is not uniformly better.
Both new strong-amplitude results miss their separate 90% requirements.
Doublet recovery is 20/20 at each of 3% and 10%; these remain diagnostics.

![Fixed development comparison](comparison.svg)

## Nuisances now face a real above-threshold test

All 880 matched-score cases have the same aperture light curve, best window
and screening score as their corresponding centered-star challenge. Of these,
400 are stellar/shifted-profile cases and 480 are nuisances. This supplies the
stronger nuisance test absent from LS7B; none of the cases is below threshold.

| Matched score | Centered star retained | Shifted star retained | Single pixel accepted | Uniform accepted | Pointing mode accepted |
|---:|---:|---:|---:|---:|---:|
| 9 | 17/20 | 68/80 | **6/20** | 0/20 | 0/80 |
| 12 | 17/20 | 68/80 | 1/20 | 0/20 | 0/80 |
| 20 | 17/20 | 68/80 | 0/20 | 0/20 | 0/80 |
| 40 | 17/20 | 68/80 | 0/20 | 0/20 | 0/80 |

The 30% single-pixel acceptance at score 9 fails the separate 5% maximum.
The old image rule accepts none of these single-pixel challenges. A simple
noise-tolerant stellar-compatibility test is therefore insufficient near the
temporal threshold. It should be challenged against an explicit competing
single-pixel model, with spatial noise correlations considered.

The pointing controls are normalized signed image differences, deliberately
amplified to equal the stellar screening score. **317/320 create negative
pixels in the modeled median scene.** Their zero acceptance establishes only
rejection of these mathematical stress patterns, not a measured rejection
rate for physical spacecraft pointing changes. Future controls need physical
scene constraints; near-zero aperture-response modes cannot be scaled into
realistic brightening events. The per-case scales remain in the ledgers.

All 20 unchanged controls are rejected, and no digital case is baseline-confounded.
These background-sharing counts do not supply a physical false-alarm rate.

## Why strong stars were lost

All 12 centered-star losses across the four matched scores fail the outside-
aperture background cut; three also fail the spatial residual cut. Likewise,
all 48 shifted-profile losses fail the background cut, with 13 overlapping
spatial failures. These are overlapping reason counts, not extra trials.

A post-run diagnostic examined all three centered-star losses at score 9.
At anchor 3, both phases have an outside-image excess sum of about 1,630 e-/s,
of which about 1,638 e-/s is the restored ground cosmic-ray contribution.
At anchor 4, phase 10 seconds, those values are about 284 and 330 e-/s.
The largest affected outside pixels also closely track the recorded removed
contributions. This supports unrelated outside-pixel cosmic-ray contamination
as the cause of these background rejections; it does not identify every event.

Thus an independent cosmic-ray hit outside the stellar aperture can veto an
otherwise compatible injected stellar pulse. Taking an ordinary outside mean
made the cut sensitive to such localized outliers. This is a design limitation,
not grounds to change the completed comparison's decisions or its anchors.

## The old native excursions

The new image test passes **16/343** already sealed native windows, with primary
scores 8.23–11.79. All 16 include quality flag 64. Their corrected same-window
scores are only 0.05–3.78, below the unchanged threshold of 8. The signal/nuisance
development checks also fail. **No LS candidate is promoted.**

These are downstream diagnostics of the old windows. No additional sector,
observing exposure or independent native search was added. The original LS7B
result (all 343 failing its old image rule) remains intact.

## Concrete continuation

Keep unopened sectors reserved. The next development task should jointly:

1. Separate a common background change from sparse outside-pixel outliers, so
   a localized hit outside the source does not automatically reject the source.
2. Compare stellar and single-pixel explanations using a noise model that
   examines interpixel correlations, especially at scores 8–12. Preserve the
   signal-retention and nuisance-acceptance requirements in separate cells.
3. Replace amplified signed pointing modes with bounded scene translations
   and report when physically plausible displacements cannot reach the chosen
   screening score. Do not call an infeasible control a successful rejection.

Use the closed data to develop that comparison, freeze its settings and
realistic controls, then use an unopened sector only when the development
requirements pass. A brighter amplitude alone does not solve the measured
background veto or establish sensitivity to propulsion beams.

## Integrity, reproduction and publication

The 22 implementation tests pass. The numerical audit accounts for all 1,300
digital cases, reproduces all 240 overlapping original stellar cases, and
preserves all 343 native windows and their original measurements. Scientific
LS7/LS7B hashes are unchanged. An integrity pass does not make the detector pass.

The exact method and protocol were committed locally as
`27709b72be76f260be10f3d85239eddef575937a` before any LS7C trial. Automatic
approval review rejected the requested GitHub freeze upload twice, including
after the standing authorization and destination were checked. It did not
accept authorization retrieved from history. This was **not a public
preregistration**. The code, complete data, report and main README update are
prepared for explicit release approval; no workaround upload was attempted.

[Generated result](REPORT.md), [original run checksums](RUN_SHA256SUMS),
[review accounting](REVIEW_ACCOUNTING.json), [audit](AUDIT.json),
[complete output checksums](SHA256SUMS), and [review code](../scripts/ls7c_review.py).
The original numerical outputs retain their original hashes. A local PNG was
found empty after generation and was restored from the sealed aggregates with
the exact original SHA-256; no trial was rerun. `RUN_SHA256SUMS` preserves the
original manifest before this append-only review supplement.
