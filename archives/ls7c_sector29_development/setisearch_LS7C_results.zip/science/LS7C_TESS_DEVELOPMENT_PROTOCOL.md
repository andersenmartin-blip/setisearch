# LS7C: noise-aware images and matched-strength development challenges

12 September 2026. Develop the concrete continuation from the closed
[LS7B review](results_ls7b_tess/REVIEW.md). **This is retrospective method
development on sector 29, not a new independent evaluation.** No additional
TESS sector is opened. Preserve all original LS7/LS7B code, thresholds, outputs
and denominators. Fix this comparison before running its real-data trials,
including unsuccessful endpoints without retuning the comparison.

Publication timing note, added before any LS7C real-data trial: automatic
approval review rejected the proposed GitHub upload twice. It did not accept
the owner's standing authorization retrieved from conversation history.
Publication remains blocked; no alternative upload route is attempted. Seal
the exact protocol and code in a local Git commit before running this
retrospective comparison. The original plan to publish the freeze first cannot
be fulfilled in this turn. Record this limitation explicitly; the local freeze
is not a public preregistration. No detector or trial settings changed in
response to this publication issue, and no new sector is opened.

## Inputs and unchanged arithmetic

Use the same two public L 98-59 sector 29 FITS products and their LS7B source
SHA-256 identities, the same ten nonoverlapping 401-row backgrounds, the same
saved per-run noise scales and the same restored pixels. Recheck both old
scientific freezes and every original LS7B output checksum. Confirm that
time/quality-selected anchors are identical. No new temporal search is needed:
reuse the 343 sealed native event windows for a downstream image diagnostic.

Keep quality bits 64/1024, gap handling, 121-row median detrending, 2/3/5-row
boxes, score threshold 8, event matching and confounding unchanged. Every
digital row records both the old and new image decisions at the same highest-
scoring window. Verify that the 240 overlapping stellar trials reproduce
the closed LS7B scores, windows, confounding and old-image decisions. This
does not amend LS7B's reported 5/60 bright-single recovery or failed gate.

## New image rule

Use two separated sidebands, [start-60,start-5) and [stop+5,stop+60), restricted
to the current contiguous good segment. Require at least 20 rows on each side,
finite aperture pixels and at least three finite outside pixels. No zero-noise
or nonfinite input can pass by omission.

For each aperture pixel, estimate the cadence variance from the MAD of first
differences within each sideband (never across the gap), divided by two.
Independently estimate variance of nonoverlapping, width-row sideband means.
Use the larger of cadence variance / width and that binned variance, then add
pi/(2*N_side) times cadence variance for uncertainty of the median reference.
This is a practical diagonal noise model. It does not fully model interpixel
covariance, nonstationarity, uncertainty of the profile, or the selection of
the largest temporal score. The binned estimate addresses some time correlation.

The median sideband stellar image is positive-clipped, aperture-restricted and
normalized. Compare the mean excess to nine bilinearly shifted versions at
all pairs in {-0.25,0,+0.25} pixels. Fit one nonnegative amplitude by weighted
least squares for each, and retain the least weighted squared residual Q.
Require positive amplitude and Q <= the 0.999 chi-square reference quantile
with N_aperture-1 degrees of freedom. The reference curve supplies a fixed
engineering cut; searching nine profiles and using estimated, correlated noise
means it is **not a calibrated p-value or false-alarm probability**.

Independently form the outside-aperture mean time series and apply the same
sideband noise calculation to it. Require absolute mean-event excess relative
to its median sideband level <= 4 noise units. This empirical scalar calculation
retains spatial correlation in the outside mean. All settings are in
`config/ls7c_tess_development.json`; no old cosine or centroid veto is added.
The profile is an empirical aperture image, not a full optical PSF model.

## Fixed 1,300 digital trials

All trials share the same ten backgrounds and phases 0/10 seconds.

1. **400 amplitude-grid stellar trials:** four old shapes (30/60/100-second
   top hats and the 30-second doublet separated by 87 seconds), at 0.1%, 0.3%,
   1%, 3%, and 10% extra aperture flux. The first three amplitudes reproduce
   the old stellar inputs; the new amplitudes were specified before this run.
2. **880 matched-score trials:** for a 30-second pulse solve the added aperture
   amplitude by 36 fixed bisection iterations to reach temporal score 9, 12,
   20 or 40. The bracket is zero to the median aperture flux; abort if it is
   invalid or the unchanged background already reaches the requested score.
   This is planned conditional challenge generation, not a sensitivity curve.
   At each score use eleven spatial patterns: one centered star, four stars
   shifted +/-0.2 pixel along either axis (off the fit-bank grid), one peak
   pixel, one uniform stamp, and four normalized signed pointing modes.
3. **20 unchanged controls.**

Each matched pattern has unit sum in the aperture. Its full aperture light
curve, best window and score must agree with the centered-star challenge
within 1e-6 score units; require maximum aperture light-curve discrepancy
below 1e-8 of the median aperture flux. Do not fit amplitude to image acceptance.
All 880 examples must reach threshold; report every matching failure as a
failed endpoint. This fixes LS7B's absence of above-threshold nuisance tests.

The pointing modes are the LS7B signed differences of a shifted median scene,
normalized to unit aperture change. Record the original +/-0.2-pixel mode,
signed scale, and maximum perturbation relative to each positive scene pixel.
These are deliberately amplified stress patterns; they do **not** represent
literal spacecraft translations of that size at the matched brightness.
Near-zero aperture-response modes (<1e-8 of scene aperture flux) stop the run.
Report extreme fractional changes and negative modeled scene pixels.

Injections are deterministic additions after processing, with background noise
fixed. They add no source photon-noise realization and do not measure losses
from upstream calibration, readout, target selection or quality cuts. The
strong grid is conditional digital recovery, not end-to-end sensitivity.

## Predeclared development checks

Require all endpoints and source checks, and all of:

- At least 90% recovery separately for the 60 single pulses at 3% and the 60
  at 10%. Doublets remain reported diagnostics.
- At least 95% centered-star recovery and 90% off-profile recovery separately
  at each of the four matched scores (20 and 80 trials per score).
- At most 5% nuisance acceptance separately for each kind **and score**
  (20 single-pixel, 20 uniform, and 80 pointing-mode trials per score).
- No unchanged control accepted, and no baseline-confounded digital row.
- All matched light curves/windows/scores agree and all reach threshold.

These checks select whether the method is ready for a separately frozen
unopened-sector evaluation. Passing them cannot qualify a sky search on
data already used for development. Failures remain visible; do not pool
strengths or nuisance kinds to hide a failed cell, and do not tune and rerun
this named comparison. Correlated repeated backgrounds prohibit binomial
confidence claims using the digital trial count as independent sample size.

## Native diagnostics and outputs

Recompute only image compatibility for the 343 old native excursions. Their
temporal scores, old morphology and corrected-window scores remain linked to
the original sealed ledger. A new image pass is a development diagnostic,
never a promoted LS candidate. There is no new sky-coverage denominator.

Publish per-anchor deterministic compressed JSONL trial ledgers, compressed
native diagnostic parts, complete group denominators, gate checks, source and
code identities, a report, comparison figure and checksums. Refuse to replace
an existing output directory; preserve partial per-anchor output on failure.
An audit verifies expected case identities, all 1,300 decisions, all 343 native
windows, exact matching and source/old-result preservation.

If the checks pass, freeze this rule and the same challenge design in a
separate validation protocol before opening the next metadata-selected sector.
If they fail, use the measured failure to choose the next development question;
preserve unopened sectors and do not claim detector adoption.

## Reproduce

```sh
python -m pip install -r requirements_ls7.txt
PYTHONPATH=src python -m unittest discover -s tests -p 'test_ls7*.py' -v
sha256sum -c LS7C_FREEZE.sha256
PYTHONPATH=src python scripts/ls7c_tess_development.py --cache data_ls7b_tess
PYTHONPATH=src python scripts/ls7c_tess_development.py --audit results_ls7c_tess
```

Mission processing is described by the
[NASA TESS cosmic-ray primer](https://heasarc.gsfc.nasa.gov/docs/tess/TESS-CosmicRayPrimer.html)
and [MAST data definitions](https://outerspace.stsci.edu/spaces/TESS/pages/14563420/2.0%2B-%2BData%2BProduct%2BOverview),
checked 12 September 2026. Ground correction restoration remains the old
implementation; neither reference validates this new statistical discriminator.
