"""LS7C noise-aware image compatibility and matched-aperture challenges.

This is a fixed development comparison on the closed LS7B evidence. Scores and
chi-square reference cuts are engineering statistics, not calibrated p-values.
"""
import numpy as np
from scipy.stats import chi2

from .light_sail_tess_v2 import match_trial, pointing_delta, shifted_profile


def mad_sigma(values, axis=0):
    center = np.median(values, axis=axis, keepdims=True)
    return 1.482602218505602 * np.median(np.abs(values - center), axis=axis)


def mean_difference_variance(left, right, width):
    """Noise of an event mean minus a sideband median, in flux-rate units.

Never difference or bin across the excluded event. The maximum of adjacent-
difference and width-binned MAD estimates guards against some temporal noise.
The median-reference term is an approximation, not a covariance calibration.
"""
    if width < 1 or min(len(left), len(right)) < max(20, 4 * width):
        raise ValueError("insufficient separated sidebands")
    differences = np.concatenate([np.diff(left, axis=0), np.diff(right, axis=0)])
    cadence_var = mad_sigma(differences) ** 2 / 2
    blocks = []
    for side in (left, right):
        n = len(side) // width
        blocks.append(side[:n * width].reshape((n, width) + side.shape[1:]).mean(axis=1))
    binned_var = mad_sigma(np.concatenate(blocks)) ** 2
    variance = np.maximum(cadence_var / width, binned_var)
    variance += np.pi * cadence_var / (2 * (len(left) + len(right)))
    if not np.all(np.isfinite(variance)) or np.any(variance <= 0):
        raise ValueError("nonpositive or nonfinite sideband variance")
    return variance


def fit_profile_bank(delta, variance, profiles):
    """Weighted one-amplitude least squares; all profiles have unit aperture sum."""
    delta, variance, profiles = map(lambda x: np.asarray(x, dtype=float), (delta, variance, profiles))
    if (delta.ndim != 1 or variance.shape != delta.shape or profiles.ndim != 2
            or profiles.shape[1] != len(delta) or not np.all(np.isfinite(delta))
            or not np.all(np.isfinite(variance)) or np.any(variance <= 0)
            or not np.all(np.isfinite(profiles)) or np.any(profiles < 0)
            or not np.allclose(profiles.sum(axis=1), 1, rtol=0, atol=1e-12)):
        raise ValueError("invalid weighted profile inputs")
    precision = 1 / variance
    information = np.sum(profiles * profiles * precision, axis=1)
    amplitude = np.maximum(0, np.sum(profiles * delta * precision, axis=1) / information)
    residual = delta[None, :] - amplitude[:, None] * profiles
    q = np.sum(residual * residual * precision, axis=1)
    index = int(np.argmin(q))
    return {"q": float(q[index]), "profile_index": index,
            "amplitude_e_per_s": float(amplitude[index]),
            "amplitude_score": float(amplitude[index] * np.sqrt(information[index]))}


def noise_aware_pixel(cube, aperture, start, stop, cfg, sign=1):
    """Compare an excess image to a small bank of stellar profiles with pixel noise."""
    failure = {"pass": False}
    try:
        if not 0 <= start < stop <= len(cube) or sign not in (-1, 1):
            raise ValueError("invalid event window")
        left = cube[max(0, start - 60):max(0, start - 5)]
        right = cube[min(len(cube), stop + 5):min(len(cube), stop + 60)]
        event = cube[start:stop]
        if min(len(left), len(right)) < 20:
            raise ValueError("insufficient separated sidebands")
        side = np.concatenate([left, right])
        if not np.all(np.isfinite(side[:, aperture])) or not np.all(np.isfinite(event[:, aperture])):
            raise ValueError("nonfinite aperture")
        reference = np.median(side, axis=0)
        profile = np.zeros(aperture.shape)
        profile[aperture] = np.maximum(reference[aperture], 0)
        if profile.sum() <= 0 or aperture.sum() < 4:
            raise ValueError("insufficient stellar profile")
        profile /= profile.sum()
        bank = np.stack([shifted_profile(profile, aperture, d)[aperture] for d in cfg["profile_shifts_yx"]])
        delta = sign * (event[:, aperture].mean(axis=0) - reference[aperture])
        variance = mean_difference_variance(left[:, aperture], right[:, aperture], stop - start)
        fit = fit_profile_bank(delta, variance, bank)
        outside = ~aperture & np.all(np.isfinite(side), axis=0) & np.all(np.isfinite(event), axis=0)
        if outside.sum() < 3:
            raise ValueError("insufficient finite background pixels")
        # Work with the whole outside-pixel mean time series, retaining its
        # empirical spatial correlations instead of assuming independent pixels.
        outside_left = left[:, outside].mean(axis=1)
        outside_right = right[:, outside].mean(axis=1)
        outside_delta = event[:, outside].mean() - np.median(np.r_[outside_left, outside_right])
        outside_variance = mean_difference_variance(outside_left, outside_right, stop - start)
        outside_score = float(abs(outside_delta) / np.sqrt(outside_variance))
        limit = float(chi2.ppf(cfg["residual_reference_quantile"], int(aperture.sum()) - 1))
        reasons = []
        if fit["amplitude_e_per_s"] <= 0:
            reasons.append("nonpositive_fitted_source")
        if fit["q"] > limit:
            reasons.append("spatial_residual")
        if outside_score > cfg["outside_score_max"]:
            reasons.append("outside_background")
        return {"pass": not reasons, "reasons": reasons, **fit,
                "q_limit": limit, "reference_dof": int(aperture.sum()) - 1,
                "profile_shift_yx": cfg["profile_shifts_yx"][fit["profile_index"]],
                "outside_score": outside_score, "outside_pixels": int(outside.sum()),
                "sideband_rows": len(side), "median_pixel_mean_error_e_per_s": float(np.median(np.sqrt(variance)))}
    except ValueError as error:
        return {**failure, "reasons": [str(error)]}


def spatial_patterns(reference, aperture, cfg):
    """All challenge modes add the same aperture sum, including signed modes.

    Normalized pointing modes are stress shapes, not literal displacements of
    the entire star at the reported amplitude. Their scaling is recorded.
    """
    profile = np.zeros(aperture.shape)
    profile[aperture] = np.maximum(reference[aperture], 0)
    if profile.sum() <= 0:
        raise ValueError("nonpositive challenge profile")
    profile /= profile.sum()
    result = [("stellar", "center", profile, {})]
    for d in cfg["injection_shifts_yx"]:
        result.append(("off_profile", str(d), shifted_profile(profile, aperture, d), {"shift_yx": d}))
    pixel = np.zeros(aperture.shape)
    pixel.flat[np.argmax(profile)] = 1
    result.append(("single_pixel", "peak", pixel, {}))
    result.append(("uniform", "stamp", np.ones(aperture.shape) / aperture.sum(), {}))
    for d in cfg["pointing_shifts_yx"]:
        delta = pointing_delta(reference, d)
        net = float(delta[aperture].sum())
        if abs(net) < cfg["pointing_net_min_fraction"] * profile[aperture].sum() * reference[aperture].sum():
            raise ValueError("pointing mode has near-zero aperture response")
        result.append(("pointing_mode", str(d), delta / net,
                       {"shift_yx": d, "unscaled_aperture_delta_e_per_s": net}))
    return result


def solve_aperture_amplitude(native, pulse, seconds, centers, sigma, cfg, target_score, iterations):
    """Fixed deterministic amplitude search; never conditions on pixel acceptance."""
    original, confounded = match_trial(native, native, seconds, centers, sigma, cfg)
    if original["score"] >= target_score:
        raise ValueError("unchanged background already reaches target score")
    lo, hi = 0., float(np.median(native))
    upper, _ = match_trial(native, native + hi * pulse, seconds, centers, sigma, cfg)
    if upper["score"] < target_score:
        raise ValueError("target score unbracketed below 100% aperture amplitude")
    for _ in range(iterations):
        mid = (lo + hi) / 2
        trial, _ = match_trial(native, native + mid * pulse, seconds, centers, sigma, cfg)
        if trial["score"] < target_score:
            lo = mid
        else:
            hi = mid
    best, _ = match_trial(native, native + hi * pulse, seconds, centers, sigma, cfg)
    return hi, best, confounded
