#!/usr/bin/env python3
"""Execute/audit the fixed LS7C development comparison on closed LS7B inputs."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import gzip
import importlib.metadata
import json
from pathlib import Path
import platform
import subprocess
import warnings

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from ls7_tess_pilot import ROOT, load_products, save_json, sha256
from ls7b_tess_pilot import read_preflight, seal
from seti_repeater.light_sail_tess import pixel_diagnostic, pulse_shape
from seti_repeater.light_sail_tess_v2 import match_trial
from seti_repeater.light_sail_tess_v3 import noise_aware_pixel, solve_aperture_amplitude, spatial_patterns


def check_sums(manifest, root):
    names = []
    for line in manifest.read_text().splitlines():
        expected, name = line.split(maxsplit=1)
        if sha256(root / name) != expected:
            raise ValueError("checksum mismatch: " + name)
        names.append(name)
    return names


def jsonl(path, rows):
    data = "".join(json.dumps(r, separators=(",", ":"), allow_nan=False) + "\n" for r in rows).encode()
    path.write_bytes(gzip.compress(data, mtime=0))


def read_rows(output, pattern):
    return [json.loads(line) for p in sorted(output.glob(pattern)) for line in gzip.decompress(p.read_bytes()).decode().splitlines()]


def case_id(anchor, phase, panel, kind, variant, shape, level):
    return f"{anchor}:{phase:g}:{panel}:{kind}:{variant}:{shape}:{level:g}"


def expected_cases(base, cfg):
    cases = set()
    patterns = [("stellar", "center"), *[("off_profile", str(d)) for d in cfg["injection_shifts_yx"]],
                ("single_pixel", "peak"), ("uniform", "stamp"),
                *[("pointing_mode", str(d)) for d in cfg["pointing_shifts_yx"]]]
    for a in range(base["injections"]["anchors"]):
        for phase in base["injections"]["phases_seconds"]:
            for shape in base["injections"]["shapes"]:
                for amp in cfg["amplitude_grid"]:
                    cases.add(case_id(a, phase, "amplitude", "stellar", "center", shape, amp))
            for score in cfg["target_scores"]:
                for kind, variant in patterns:
                    cases.add(case_id(a, phase, "matched", kind, variant, cfg["matched_shape"], score))
            cases.add(case_id(a, phase, "null", "null", "unchanged", cfg["matched_shape"], 0))
    return cases


def evaluate(local, aperture, seconds, sigma, phase, shape, amount, pattern, base, cfg):
    pulse, centers = pulse_shape(seconds, phase, shape, base["cadence_seconds"])
    native = local[:, aperture].sum(axis=1)
    injected = local + (amount * pulse)[:, None, None] * pattern
    injected_flux = injected[:, aperture].sum(axis=1)
    best, confounded = match_trial(native, injected_flux, seconds, centers, sigma, base)
    old = pixel_diagnostic(injected, aperture, best["start"], best["stop"], base["morphology"])
    new = noise_aware_pixel(injected, aperture, best["start"], best["stop"], cfg["pixel_rule"])
    detected = best["score"] >= base["score_threshold"]
    return {"best": best, "baseline_confounded": confounded, "screen_detected": bool(detected),
            "old_morphology": old, "new_morphology": new,
            "old_accepted": bool(detected and old["pass"]), "new_accepted": bool(detected and new["pass"]),
            "old_recovered": bool(detected and old["pass"] and not confounded),
            "new_recovered": bool(detected and new["pass"] and not confounded),
            "actual_amplitude_fraction": float(amount / np.median(native)),
            "max_lightcurve_fraction_error": float(np.max(np.abs(injected_flux - native - amount * pulse)) / np.median(native))}


def counts(rows):
    return {"trials": len(rows), **{key: sum(r[key] for r in rows) for key in
            ("screen_detected", "old_accepted", "new_accepted", "old_recovered", "new_recovered", "baseline_confounded")}}


def summarize(rows, cfg):
    grouped = []
    keys = sorted({(r["panel"], r["kind"], r["shape"], r["level"]) for r in rows})
    for panel, kind, shape, level in keys:
        group = [r for r in rows if (r["panel"], r["kind"], r["shape"], r["level"]) == (panel, kind, shape, level)]
        grouped.append({"panel": panel, "kind": kind, "shape": shape, "level": level, **counts(group)})
    gates = {}
    q = cfg["development_gates"]
    for amp in q["strong_amplitudes"]:
        group = [r for r in rows if r["panel"] == "amplitude" and r["level"] == amp and r["shape"] != "doublet30sep87"]
        gates[f"single_recovery_{amp:g}"] = sum(r["new_recovered"] for r in group) >= q["strong_single_recovery_min"] * len(group) > 0
    for score in cfg["target_scores"]:
        for kind in ("stellar", "off_profile", "single_pixel", "uniform", "pointing_mode"):
            group = [r for r in rows if r["panel"] == "matched" and r["level"] == score and r["kind"] == kind]
            if kind in ("stellar", "off_profile"):
                threshold = q["matched_center_retention_min_per_score"] if kind == "stellar" else q["matched_off_profile_retention_min_per_score"]
                passed = sum(r["new_recovered"] for r in group) >= threshold * len(group) > 0
            else:
                passed = bool(group) and sum(r["new_accepted"] for r in group) <= q["matched_nuisance_acceptance_max_per_kind_and_score"] * len(group)
            gates[f"{kind}_score_{score:g}"] = passed
    matched = [r for r in rows if r["panel"] == "matched"]
    gates["all_matched_reach_screen"] = len(matched) == 880 and all(r["screen_detected"] for r in matched)
    gates["exact_matching"] = all(r["window_matches_reference"] and r["observed_score_difference"] <= cfg["score_matching_tolerance"]
                                  and abs(r["best"]["score"] - r["level"]) <= cfg["score_matching_tolerance"]
                                  and r["max_lightcurve_fraction_error"] < 1e-8 for r in matched)
    gates["unchanged_controls"] = sum(r["new_accepted"] for r in rows if r["panel"] == "null") <= q["null_accepted_max"]
    gates["no_baseline_confounding"] = not any(r["baseline_confounded"] for r in rows)
    gates["complete_trials"] = len(rows) == cfg["expected_trials"]
    return {"groups": grouped, "totals": counts(rows), "development_gates": gates, "development_pass": all(gates.values())}


def audit(output, base, cfg):
    rows = read_rows(output, "anchor_*.jsonl.gz")
    ids = [r["case_id"] for r in rows]
    if len(ids) != len(set(ids)) or set(ids) != expected_cases(base, cfg) or len(ids) != cfg["expected_trials"]:
        raise ValueError("incomplete, extra or duplicate digital cases")
    previous = json.loads((ROOT / cfg["source_result"] / "baseline_trials.json").read_text())
    old_map = {(r["anchor"], r["phase_seconds"], r["shape"], r["amplitude_fraction"]): r for r in previous if r["kind"] == "stellar"}
    overlap = 0
    for row in rows:
        if row["case_id"] != case_id(row["anchor"], row["phase_seconds"], row["panel"], row["kind"], row["variant"], row["shape"], row["level"]):
            raise ValueError("case fields differ from identity")
        detected = row["best"]["score"] >= base["score_threshold"]
        if detected != row["screen_detected"]:
            raise ValueError("screen decision mismatch")
        for name in ("old", "new"):
            passed = row[name + "_morphology"]["pass"]
            if row[name + "_accepted"] != (detected and passed) or row[name + "_recovered"] != (detected and passed and not row["baseline_confounded"]):
                raise ValueError("combined image decision mismatch")
        fit = row["new_morphology"]
        if "q" in fit:
            expected = fit["amplitude_e_per_s"] > 0 and fit["q"] <= fit["q_limit"] and fit["outside_score"] <= cfg["pixel_rule"]["outside_score_max"]
            if fit["pass"] != expected:
                raise ValueError("weighted image gate mismatch")
        if row["panel"] == "amplitude" and row["level"] in base["injections"]["amplitudes"]:
            original = old_map[(row["anchor"], row["phase_seconds"], row["shape"], row["level"])]
            if (row["best"]["start"], row["best"]["stop"]) != (original["best"]["start"], original["best"]["stop"]) or abs(row["best"]["score"] - original["best"]["score"]) > 1e-7:
                raise ValueError("closed LS7B window or score changed")
            if row["old_recovered"] != original["recovered"] or row["old_morphology"]["pass"] != original["morphology_pass"] or row["baseline_confounded"] != original["baseline_confounded"]:
                raise ValueError("closed LS7B classification changed")
            overlap += 1
    native = read_rows(output, "native_*.jsonl.gz")
    original_native = json.loads((ROOT / cfg["source_result"] / "restored_events.json").read_text())
    if len(native) != len(original_native) or any({k: r[k] for k in original} != original for r, original in zip(native, original_native)):
        raise ValueError("closed native ledger changed")
    if overlap != 240:
        raise ValueError("missing original stellar comparisons")
    computed = summarize(rows, cfg)
    summary = json.loads((output / "summary.json").read_text())
    for key, value in computed.items():
        if summary[key] != value:
            raise ValueError("summary accounting mismatch: " + key)
    return {"pass": True, "digital_cases": len(rows), "closed_stellar_cases_reproduced": overlap,
            "native_windows_preserved": len(native), "case_identity_and_decision_checks": True,
            "summary_and_gate_accounting": True, "claim": "Integrity audit; does not make development checks pass."}


def write_report(output, summary, rows, cfg):
    groups, gates = summary["groups"], summary["development_gates"]
    text = ["# LS7C: noise-aware TESS image comparison", "", "12 September 2026. **Closed-data development checks: " + ("PASS" if summary["development_pass"] else "FAIL") + ".**",
            "", "All 1,300 digital trials completed on the same ten LS7B sector 29 backgrounds. No new sector was opened. This is method development, not independent detector qualification or new sky coverage.",
            "", "## Amplitude-grid recovery", "", "Old and new image rules use exactly the same temporal scores and event windows. Counts below are conditional digital recoveries after both stages.", "",
            "| Shape | Added aperture light | Reaches screen | Old recovery | New recovery | Trials |", "|---|---:|---:|---:|---:|---:|"]
    for g in groups:
        if g["panel"] == "amplitude":
            text.append(f"| {g['shape']} | {100*g['level']:g}% | {g['screen_detected']} | {g['old_recovered']} | {g['new_recovered']} | {g['trials']} |")
    text += ["", "## Challenges with identical aperture light curves", "", "Every matched case reaches screening. Centered stars, shifted stars and nuisances have the same best temporal window and score in their matched group. Nuisance acceptance therefore tests the spatial rule above threshold.", "",
             "| Score | Pattern | Old accepted | New accepted | Trials |", "|---:|---|---:|---:|---:|"]
    for g in sorted((g for g in groups if g["panel"] == "matched"), key=lambda g: (g["level"], g["kind"])):
        text.append(f"| {g['level']:g} | {g['kind']} | {g['old_accepted']} | {g['new_accepted']} | {g['trials']} |")
    text += ["", "## Fixed checks", "", "| Check | Result |", "|---|---|"]
    text += [f"| {k} | {'PASS' if v else 'FAIL'} |" for k, v in gates.items()]
    native = summary["native"]
    text += ["", "## Native and integrity diagnostics", "",
             f"The new image rule passes {native['new_pixel_pass']}/{native['windows']} previously sealed native windows. All old windows and their old measurements are preserved. These are retrospective diagnostics, not promoted candidates. None of the original windows reaches threshold on the corrected stream with the original noise scale.", "",
             "The 240 overlapping stellar cases reproduce the original LS7B windows, scores and old classifications. LS7B's 5/60 recovery at 1% remains its original result. [Audit](AUDIT.json).", "",
             "## Interpretation and continuation", "",
             "See [REVIEW.md](REVIEW.md) for interpretation of the complete fixed result and the next concrete step. The checks cannot establish independent qualification even if all pass. No rule is adopted for a sky survey in this development run.", "",
             "The image model uses empirical diagonal pixel noise and a small shifted-profile bank. The residual reference cut is not a calibrated probability. Trials share ten backgrounds; no independent-trial confidence interval is inferred. Source injections add deterministic light without additional photon noise and occur after mission processing. Stellar flares and unresolved astrophysical sources remain possible passes.", "",
             "Normalized signed pointing modes are deliberately amplified spatial stress patterns. They do not represent literal translations with a measured physical occurrence rate. Their signed scales, fractional pixel changes and negative modeled scene counts are in the ledgers.", "",
             "[Comparison figure](comparison.svg), [machine-readable summary](summary.json), [input identities](provenance.json), [protocol](../LS7C_TESS_DEVELOPMENT_PROTOCOL.md), [output checksums](SHA256SUMS).",
             "", "Per-anchor and native-part `*.jsonl.gz` files are ordinary deterministic gzip JSONL. Read with Python's gzip module. Run the `--audit` command in the protocol to verify full membership and decision accounting.", "",
             "Scientific code commit: `" + summary["code_commit"] + "`. Freeze SHA-256: `" + summary["freeze_sha256"] + "`."]
    (output / "REPORT.md").write_text("\n".join(text) + "\n")
    fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.5), layout="constrained")
    colors = {"box30": "#087e8b", "box60": "#c06014", "box100": "#6e42a1"}
    for shape, color in colors.items():
        gs = [g for g in groups if g["panel"] == "amplitude" and g["shape"] == shape]
        x = [100*g["level"] for g in gs]
        axes[0].plot(x, [g["new_recovered"]/g["trials"] for g in gs], "o-", color=color, label=shape + " new")
        axes[0].plot(x, [g["old_recovered"]/g["trials"] for g in gs], "--", color=color, alpha=.55)
    axes[0].set(xscale="log", xlabel="Added aperture light (%)", ylabel="Digital recovery", ylim=(-.03, 1.04), title="Solid: noise-aware; dashed: old image rule")
    axes[0].legend(fontsize=8)
    for kind in ("stellar", "off_profile", "single_pixel", "uniform", "pointing_mode"):
        gs = [g for g in groups if g["panel"] == "matched" and g["kind"] == kind]
        axes[1].plot([g["level"] for g in gs], [g["new_accepted"]/g["trials"] for g in gs], "o-", label=kind, alpha=.8)
    axes[1].set(xlabel="Matched temporal screening score", ylabel="New image acceptance", ylim=(-.03, 1.04), title="All matched nuisances reach screening")
    axes[1].legend(fontsize=8)
    fig.suptitle("L 98-59 sector 29 · 1,300 trials on ten reused backgrounds · development only", fontsize=11)
    fig.savefig(output / "comparison.svg")
    fig.savefig(output / "comparison.png", dpi=150)
    plt.close(fig)


def execute(args, base, cfg, summary):
    source = ROOT / cfg["source_result"]
    manifest = json.loads((source / "source_manifest.json").read_text())
    paths = {}
    for product in manifest["products"]:
        path = args.cache / product["name"]
        if path.stat().st_size != product["bytes"] or sha256(path) != product["sha256"]:
            raise ValueError("raw source identity changed")
        paths[product["kind"]] = path
    check_sums(source / "SHA256SUMS", source)
    preflight, segments, _, _, _ = read_preflight(paths, base)
    if preflight != json.loads((source / "preflight.json").read_text()):
        raise ValueError("closed eligibility changed")
    cube, aperture, time, _, _, _, _, _ = load_products(paths, base)
    noise = json.loads((source / "segments.json").read_text())
    save_json(args.output / "provenance.json", {"source_products": manifest["products"], "preflight": preflight,
              "source_science_commit": "10a8e36bcb938e63e94e01c6c02bed81dd17f00b", "source_output_manifest_sha256": sha256(source / "SHA256SUMS")})
    half = base["injections"]["context_half_samples"]
    all_rows = []
    for a, anchor in enumerate(preflight["anchors"]):
        local = cube[anchor-half:anchor+half+1]
        seconds = (time[anchor-half:anchor+half+1] - time[anchor]) * 86400
        native = local[:, aperture].sum(axis=1)
        flux_level = float(np.median(native))
        relevant = [n for n in noise if n["start"]+half <= anchor < n["stop"]-half]
        if len(relevant) != 1:
            raise ValueError("closed anchor noise association changed")
        sigma = relevant[0]["sigma_e_per_s"]
        reference = np.median(local, axis=0)
        patterns = spatial_patterns(reference, aperture, cfg)
        rows = []
        def append(panel, kind, variant, shape, level, phase, amount, pattern, extra=None):
            row = {"case_id": case_id(a, phase, panel, kind, variant, shape, level), "anchor": a,
                   "native_index": anchor, "btjd": float(time[anchor]), "panel": panel, "kind": kind,
                   "variant": variant, "shape": shape, "level": level, "phase_seconds": phase,
                   **evaluate(local, aperture, seconds, sigma, phase, shape, amount, pattern, base, cfg), **(extra or {})}
            rows.append(row)
            return row
        for phase in base["injections"]["phases_seconds"]:
            for shape in base["injections"]["shapes"]:
                for amp in cfg["amplitude_grid"]:
                    append("amplitude", "stellar", "center", shape, amp, phase, amp*flux_level, patterns[0][2])
            for score in cfg["target_scores"]:
                pulse, centers = pulse_shape(seconds, phase, cfg["matched_shape"], base["cadence_seconds"])
                amount, best, _ = solve_aperture_amplitude(native, pulse, seconds, centers, sigma, base, score, cfg["amplitude_search_iterations"])
                for kind, variant, pattern, extra in patterns:
                    details = dict(extra)
                    if kind == "pointing_mode":
                        positive = reference > 0
                        details.update(signed_mode_scale=amount / extra["unscaled_aperture_delta_e_per_s"],
                                       max_fractional_positive_scene_pixel_change=float(np.max(np.abs(amount*pattern[positive]/reference[positive]))),
                                       negative_modeled_scene_pixels=int(np.count_nonzero(reference + amount*pattern < 0)))
                    row = append("matched", kind, variant, cfg["matched_shape"], score, phase, amount, pattern, details)
                    row.update(reference_score=best["score"], observed_score_difference=abs(row["best"]["score"]-best["score"]),
                               window_matches_reference=(row["best"]["start"], row["best"]["stop"]) == (best["start"], best["stop"]))
            append("null", "null", "unchanged", cfg["matched_shape"], 0, phase, 0, patterns[0][2])
        jsonl(args.output / f"anchor_{a:02d}.jsonl.gz", rows)
        all_rows.extend(rows)
        summary["digital_trials_completed"] = len(all_rows)
        save_json(args.output / "progress.json", {"completed_anchors": a+1, "completed_trials": len(all_rows)})
        print(f"Anchor {a+1}/10: {len(all_rows)}/1300 trials sealed", flush=True)
    native_rows = json.loads((source / "restored_events.json").read_text())
    for row in native_rows:
        lo, hi = segments[row["segment"]]
        row["ls7c_morphology"] = noise_aware_pixel(cube[lo:hi], aperture, row["start"]-lo, row["stop"]-lo, cfg["pixel_rule"], row["sign"])
    for part, start in enumerate(range(0, len(native_rows), 100)):
        jsonl(args.output / f"native_{part:02d}.jsonl.gz", native_rows[start:start+100])
    summary.update(summarize(all_rows, cfg))
    summary.update(status="COMPLETED", native={"windows": len(native_rows), "new_pixel_pass": sum(r["ls7c_morphology"]["pass"] for r in native_rows)})
    save_json(args.output / "summary.json", summary)
    save_json(args.output / "AUDIT.json", audit(args.output, base, cfg))
    write_report(args.output, summary, all_rows, cfg)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=ROOT / "data_ls7b_tess")
    parser.add_argument("--output", type=Path, default=ROOT / "results_ls7c_tess")
    parser.add_argument("--audit", type=Path)
    args = parser.parse_args()
    for name in ("LS7C_FREEZE.sha256", "LS7B_FREEZE.sha256", "LS7_FREEZE.sha256"):
        check_sums(ROOT / name, ROOT)
    cfg = json.loads((ROOT / "config/ls7c_tess_development.json").read_text())
    base = json.loads((ROOT / cfg["source_config"]).read_text())
    if args.audit:
        names = check_sums(args.audit / "SHA256SUMS", args.audit)
        if set(names) != {p.name for p in args.audit.iterdir() if p.is_file() and p.name != "SHA256SUMS"}:
            raise ValueError("result manifest membership mismatch")
        text = audit(args.audit, base, cfg)
        text["sealed_files"] = len(names)
        print(json.dumps(text, indent=2))
        return
    if args.output.exists():
        raise RuntimeError("refusing to replace existing results")
    args.output.mkdir(parents=True)
    summary = {"schema": cfg["schema"], "claim": cfg["claim"], "run_utc": datetime.now(timezone.utc).isoformat(),
               "code_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
               "freeze_sha256": sha256(ROOT / "LS7C_FREEZE.sha256"), "digital_trials_completed": 0,
               "environment": {"python": platform.python_version(), **{p: importlib.metadata.version(p) for p in ("numpy", "scipy", "astropy", "matplotlib")}}}
    error = None
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always", RuntimeWarning)
        try:
            execute(args, base, cfg, summary)
        except Exception as exc:
            error = exc
            summary.update(status="INCOMPLETE", development_pass=False, error_type=type(exc).__name__, error=str(exc))
            (args.output / "REPORT.md").write_text("# LS7C: incomplete development comparison\n\n" + str(exc) + "\n\nCompleted trials: " + str(summary["digital_trials_completed"]) + ". Preserved partial files are not a complete result.\n")
    summary["runtime_warnings"] = dict(Counter(str(w.message) for w in caught))
    save_json(args.output / "summary.json", summary)
    seal(args.output)
    print(json.dumps({k: summary.get(k) for k in ("status", "digital_trials_completed", "development_pass", "development_gates", "error")}), flush=True)
    if error:
        raise error


if __name__ == "__main__":
    main()
