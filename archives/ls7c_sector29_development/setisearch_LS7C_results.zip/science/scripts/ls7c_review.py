#!/usr/bin/env python3
"""Retrospective loss attribution; never changes the sealed LS7C trial decisions."""
import argparse
from collections import Counter
import json
from pathlib import Path

from astropy.io import fits
import numpy as np

from ls7_tess_pilot import ROOT, load_products, save_json, sha256
from ls7c_tess_development import check_sums, read_rows


def loss_counts(group):
    return {"trials": len(group), "screen_detected": sum(r["screen_detected"] for r in group),
            "old_recovered": sum(r["old_recovered"] for r in group),
            "new_recovered": sum(r["new_recovered"] for r in group),
            "rejection_reasons_above_threshold": dict(Counter(reason for r in group if r["screen_detected"] and not r["new_recovered"] for reason in r["new_morphology"]["reasons"]))}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", required=True, type=Path)
    parser.add_argument("--output", type=Path, default=ROOT / "results_ls7c_tess")
    args = parser.parse_args()
    out = args.output / "REVIEW_ACCOUNTING.json"
    if out.exists():
        raise ValueError("refusing to replace review accounting")
    check_sums(args.output / "SHA256SUMS", args.output)
    rows = read_rows(args.output, "anchor_*.jsonl.gz")
    native = read_rows(args.output, "native_*.jsonl.gz")
    result = {"scope": "Post-run description; no new veto or detector evaluation",
              "source_run_manifest_sha256": sha256(args.output / "SHA256SUMS"),
              "single_pulses": {str(amp): loss_counts([r for r in rows if r["panel"] == "amplitude" and r["level"] == amp and r["shape"] != "doublet30sep87"]) for amp in (.01, .03, .1)}}
    matched = [r for r in rows if r["panel"] == "matched"]
    result["matched"] = {kind: loss_counts([r for r in matched if r["kind"] == kind]) for kind in sorted({r["kind"] for r in matched})}
    result["maximum_score_match_error"] = max(r["observed_score_difference"] for r in matched)
    result["maximum_target_score_error"] = max(abs(r["best"]["score"] - r["level"]) for r in matched)
    result["maximum_aperture_lightcurve_fraction_error"] = max(r["max_lightcurve_fraction_error"] for r in matched)
    point = [r for r in matched if r["kind"] == "pointing_mode"]
    result["pointing_stress_physicality"] = {
        "trials": len(point), "cases_with_negative_modeled_scene_pixels": sum(r["negative_modeled_scene_pixels"] > 0 for r in point),
        "signed_mode_scale_range": [min(r["signed_mode_scale"] for r in point), max(r["signed_mode_scale"] for r in point)],
        "largest_fractional_positive_scene_pixel_change": max(r["max_fractional_positive_scene_pixel_change"] for r in point)}
    passes = [r for r in native if r["ls7c_morphology"]["pass"]]
    result["native_passes"] = {"count": len(passes), "primary_score_range": [min(r["score"] for r in passes), max(r["score"] for r in passes)],
                               "corrected_same_window_score_range": [min(r["corrected_score_same_window"] for r in passes), max(r["corrected_score_same_window"] for r in passes)],
                               "all_include_flag_64": all(any(q & 64 for q in r["quality_words"]) for r in passes)}
    cfg = json.loads((ROOT / "config/ls7b_tess_l9859.json").read_text())
    paths = {p["kind"]: args.cache / p["name"] for p in cfg["products"]}
    for product in json.loads((ROOT / "results_ls7b_tess/source_manifest.json").read_text())["products"]:
        if sha256(paths[product["kind"]]) != product["sha256"]:
            raise ValueError("closed source hash mismatch")
    cube, aperture, *_ = load_products(paths, cfg)
    with fits.open(paths["tp"], memmap=False) as hdus:
        corrected = np.array(hdus[1].data["FLUX"], dtype=float)
    # Predetermined review subset: all centered-star losses at the lowest
    # matched score. The selection is descriptive after the completed run.
    diagnostic = []
    for row in matched:
        if row["kind"] != "stellar" or row["level"] != 9 or row["new_recovered"]:
            continue
        lo = row["native_index"] - 200 + row["best"]["start"]
        hi = row["native_index"] - 200 + row["best"]["stop"]
        side = np.r_[lo-60:lo-5, hi+5:hi+60]
        excess = cube[lo:hi].mean(axis=0) - np.median(cube[side], axis=0)
        restored = (cube[lo:hi] - corrected[lo:hi]).mean(axis=0)
        outside = ~aperture
        values = excess[outside]
        j = int(np.argmax(np.abs(values)))
        coords = np.argwhere(outside)[j]
        diagnostic.append({"case_id": row["case_id"], "anchor": row["anchor"], "phase_seconds": row["phase_seconds"],
                           "outside_score": row["new_morphology"]["outside_score"],
                           "outside_excess_sum_e_per_s": float(values.sum()),
                           "outside_restored_contribution_sum_e_per_s": float(restored[outside].sum()),
                           "largest_outside_pixel_yx": coords.tolist(), "largest_outside_excess_e_per_s": float(values[j]),
                           "restored_contribution_at_largest_outside_pixel_e_per_s": float(restored[tuple(coords)])})
    result["lowest_score_centered_losses_outside_pixel_diagnostic"] = diagnostic
    save_json(out, result)
    print(json.dumps({"review_rows": len(rows), "native_rows": len(native), "outside_loss_diagnostics": len(diagnostic)}))


if __name__ == "__main__":
    main()
