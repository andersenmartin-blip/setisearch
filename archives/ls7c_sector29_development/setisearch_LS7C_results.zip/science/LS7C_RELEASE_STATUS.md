# LS7C release and continuation

12 September 2026. LS7C is complete locally, with all 1,300 digital trials and
343 downstream native image diagnostics. The fixed development requirements
failed. Do not rerun or retune this closed comparison. Use its measured failure
to develop the next method; sectors beyond 28/29 remain unopened.

Science base: `10a8e36bcb938e63e94e01c6c02bed81dd17f00b` on
`andersenmartin-blip/setisearch`, `m43-support-qualification`.
Pre-trial local method freeze: `27709b72be76f260be10f3d85239eddef575937a`.
The prepared package includes the subsequent result commit and a Git bundle
with both local commits, plus readable payload files and a manifest.

## Publication block

Two attempts to publish the six-file method/protocol freeze with GitHub's
create-tree action were rejected by automatic approval review. The first
reason was insufficient authorization and an unverified public destination.
After checking the authenticated account, matching repository ownership,
public visibility, the existing project direction and the actual owner's
7 September standing-authorization message, the second rejection stated that
authorization from retrieved context was untrusted and required a current
explicit instruction. No tree, commit or branch mutation succeeded. No
alternative upload mechanism was attempted.

The exact scope ready for fresh approval is: all LS7C code, protocol, config,
tests, complete compressed trial/native ledgers, figures, reports, review
accounting, checksums and operational documentation to
`andersenmartin-blip/setisearch` on `m43-support-qualification`, plus the prepared
README update on `main`. This is public disclosure of that research package.
Raw FITS products and unrelated historical archives are not part of this package.

The pre-trial freeze was local because the public freeze upload was blocked.
Never describe this as public preregistration or independent sector validation.
Results and controls were not changed after their outcomes were inspected.

## Restore and publish after approval

The ZIP's `publication_manifest.json` contains exact base heads, local result
commit, files, destinations and hashes. `science/` holds new/changed research
files at their repository-relative paths. `main/README.md` is the exact prepared
main-branch edit. The Git bundle preserves the science commits relative to the
already public base, and the README patch preserves the separate main edit.

Recheck current remote heads before any publication. Preserve newer work and
use a normal fast-forward or explicit three-way integration; never force-push
an older snapshot over newer research. Verify complete destination membership
and byte identities. Publish research files before the main README links.
After the release succeeds, update the operational publication status to
completed while keeping the historical local-freeze limitation in the protocol.

The raw sources can be retrieved from the unchanged LS7B public source URLs
and checked against `results_ls7b_tess/source_manifest.json`. Reproduce only
when necessary, into a new directory. The existing complete ledgers are the
continuation point. `RUN_SHA256SUMS` preserves the initial run manifest and
`SHA256SUMS` adds the review supplement without changing any numerical output.

The unrelated historical M43AF full-archive publication block remains separate.
The package does not modify or publish that historical archive.
