"""Render saved fixed-track profiles; no search or profile optimization."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--measurement',required=True)
    parser.add_argument('--out',required=True)
    args=parser.parse_args()
    directory=Path(args.measurement)
    records=json.loads((directory/'FIXED_TOP3_PROFILES.json').read_text())
    chosen=[r for r in records if r['selected_track']['display_rank']==1]
    if len(chosen)!=3: raise ValueError('Exactly three saved origin-rank1 profiles required')
    fig,axes=plt.subplots(6,3,figsize=(13,15),constrained_layout=True)
    sources=[]
    for col,record in enumerate(chosen):
        track=record['selected_track']; path=directory/record['patch']['path']
        raw=path.read_bytes()
        if hashlib.sha256(raw).hexdigest()!=record['patch']['sha256']: raise ValueError('Saved profile differs')
        sources.append({'path':str(path),'sha256':record['patch']['sha256']})
        with np.load(path,allow_pickle=False) as data:
            residual=data['row_normalized_power']-data['fixed_flank_median_row_normalized_power'][:,:,None]
            offsets=data['source_channel_offsets']; df=float(data['df_hz'])
            scans=data['scans'].tolist()
            vmin,vmax=np.percentile(residual,[1,99])
            if not vmax>vmin: raise ValueError('Degenerate display scale')
            for row,scan in enumerate(scans):
                ax=axes[row,col]
                im=ax.imshow(residual[row,:,::-1],aspect='auto',origin='lower',
                    extent=[offsets[-1]*df,offsets[0]*df,0,16*17.986224128],
                    vmin=vmin,vmax=vmax,cmap='magma',interpolation='nearest')
                ax.axvline(0,color='cyan',lw=.6,alpha=.7)
                if col==0: ax.set_ylabel(scan.replace('epoch','scan ')+'\nElapsed time (s)')
                if row==5: ax.set_xlabel('Offset from the frozen track (Hz)')
                if row==0:
                    ax.set_title(f"{track['originating_scan']} rank 1\n{track['reference_frequency_hz']/1e6:.6f} MHz, {track['drift_hz_s']:+.3f} Hz/s")
            fig.colorbar(im,ax=axes[:,col],label='Joined-row normalized power minus saved flank baseline',shrink=.65)
    pair=chosen[0]['selected_track']['pair_id']
    fig.suptitle(pair+' — saved fixed tracks in all six scans\nExploratory ON-selected displays; colors are not calibrated SNR',fontsize=15)
    output=Path(args.out);output.parent.mkdir(parents=True,exist_ok=True)
    fig.savefig(output,dpi=130);plt.close(fig)
    receipt={'status':'RENDERED_SAVED_PROFILES_ONLY','pair_id':pair,'inputs':sources,
      'output_sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'new_searches':0,'new_telescope_bytes':0,
      'display_percentiles':[1,99],'display_scale_shared_within_origin_column':True}
    output.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n')

if __name__=='__main__': main()
