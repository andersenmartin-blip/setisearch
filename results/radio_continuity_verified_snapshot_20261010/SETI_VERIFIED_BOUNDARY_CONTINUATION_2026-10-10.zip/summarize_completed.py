"""Summarize completed saved outputs without array reads or numerical reruns."""
import csv,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PROJECT=ROOT/'project'
DEST=ROOT/'summary'
DEST.mkdir(exist_ok=True)
cases=[('pair154_155','continuation_boundaries_20261010'),('pair157_158','continuation_boundary_recovery_20261010')]
qa=PROJECT/'results/continuation_boundaries_20261010/review/QA_RECEIPT.json'
if not qa.exists():
    matches=list(PROJECT.glob('results/**/QA_RECEIPT.json'))
    matches=[p for p in matches if json.loads(p.read_text()).get('status')=='PASS_TWO_CONTINUATION_OUTPUT_FAMILIES_AND222912_BITWISE_SOURCE_CELLS']
    if len(matches)!=1:raise ValueError('Exactly one successful combined QA receipt required')
    qa=matches[0]
Q=json.loads(qa.read_text())
assert Q['status']=='PASS_TWO_CONTINUATION_OUTPUT_FAMILIES_AND222912_BITWISE_SOURCE_CELLS'
rows=[];jobs=[];pins={}
for pair,stage in cases:
    folder=PROJECT/'results'/stage/pair/'measurement'
    receipt=json.loads((folder/'EXECUTION_RECEIPT.json').read_text())
    records=json.loads((folder/'FIXED_TOP3_PROFILES.json').read_text())
    assert receipt['search_summary']['completed_scan_tiles']==6 and len(records)==9
    jobs.append({'pair_id':pair,'receipt_status':receipt['status'],
       'search':receipt['search_summary'],'CPU_s':receipt['process_CPU_seconds_including_imports'],
       'wall_s':receipt['wall_seconds_including_imports'],'peak_RSS_bytes':receipt['peak_RSS_bytes'],
       'public_freeze_commit':receipt['public_freeze_commit'],
       'rank_score_max':max(r['selected_track']['maximum_robust_box_track_score'] for r in records)})
    for record in records:
        t=record['selected_track']
        for s in record['scan_profiles']:
            rows.append({'pair_id':pair,'track_id':t['track_id'],'originating_scan':t['originating_scan'],
              'rank':t['display_rank'],'reference_frequency_MHz':t['reference_frequency_hz']/1e6,
              'drift_Hz_s':t['drift_hz_s'],'width_channels':t['width_channels'],
              'robust_rank_score':t['maximum_robust_box_track_score'],'scan':s['scan_id'],
              'mean_center_minus_flank':s['mean_center_minus_flank'],
              'first_eight_mean':s['first_eight_mean_center_minus_flank'],
              'last_eight_mean':s['last_eight_mean_center_minus_flank']})
    for name in ['EXECUTION_RECEIPT.json','FIXED_TOP3_PROFILES.json','DRIFT_TOP20.json']:
        p=folder/name;pins[str(p.relative_to(ROOT))]=hashlib.sha256(p.read_bytes()).hexdigest()
summary={'status':'COMPLETE_SAVED_OUTPUT_SUMMARY','jobs':jobs,'verified_counts':Q['counts'],
 'new_carrier_edge_bandwidth_per_ON_Hz':sum(j['search']['new_channel_edge_bandwidth_per_ON_hz'] for j in jobs),
 'drift_width_combinations':Q['counts']['carrier_maximum_records']*1526,
 'total_numeric_CPU_s':sum(j['CPU_s'] for j in jobs),'QA_CPU_s':Q['process_CPU_seconds_including_imports'],
 'new_telescope_power_bytes':0,'new_observation_visits':0,'qualified_SETI_detections':0,
 'source_visit':'2016-03-17 HIP98505 cadence85030','prior_lock_failures_preserved':True,
 'input_SHA256':pins,'QA_receipt_SHA256':hashlib.sha256(qa.read_bytes()).hexdigest(),
 'limitations':['Exploratory ON-selected ranks; robust scores are not calibrated SNR or significance.',
 'All six scans share one historical visit; templates and ranks are correlated.',
 'Low exact-track OFF residual does not demonstrate a quiet neighboring OFF region.',
 'Full original telescope-file MD5 has not been verified. Old A/B failures and protected holdouts remain unchanged.']}
(DEST/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
with (DEST/'SIX_SCAN_PROFILES.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
text=('SETI — completed internal-boundary continuation, 10 October 2026\n\n'
 'Two previously unreached boundary searches completed: native154+155 and157+158. '
 'They add46,456.888 Hz of reference-carrier bandwidth per ON scan in already retained2016 data. '
 'They do not add a new observation visit or new telescope source bytes.\n\n'
 'Verified work:12 carrier maps,49,152 ON-origin/carrier maxima,75,005,952 correlated drift-width combinations, '
 '120 top20 entries,18 fixed top3 profiles and108 six-scan profile rows. '
 '384 decoded source-row SHA256s and222,912 saved raw-cell occurrences match source data bit for bit.\n\n'
 'The strongest retained rank scores are5.841219633477111 for154+155 and5.6353 (rounded) for157+158. '
 'These are robust ranking scores, not SNR or p-values. Positive ON-selected traces remain exploratory and unresolved. '
 'There is no qualified SETI detection or calibrated general null result.\n\n'
 'A separate descriptive review of90 previously saved selected profiles (540 scan profiles) demonstrates nearby OFF structure. '
 'For example,158/batch1 ON2/rank2 has exact OFF-track means0.081 and0.305, while per-row neighboring width1 peak means are about40,153 and40,663. '
 'Flexible local maxima are biased upward and are not a statistical veto; they establish why exact-track OFF numbers alone are inadequate.\n\n'
 'The first boundary job completed under public freeze627d5254ae218f272ea81a2008ada77ca87a6dd2. '
 'The initial second-job invocation failed before data loading on a retained existence-lock file. Its zero-map failure receipt is preserved. '
 'A separately frozen control correction uses an OS-held flock rather than file existence. '
 'Only the previously unstarted157+158 numerical search ran under1ce3be5a57c53279702e1604165e037636e9e68b; no scientific search was repeated.\n\n'
 'Saved scientific outputs, scopes, code, integrity receipts, fixed profiles and figures are included. '
 'Original compact HDF5 inputs remain in their separately retained RAW archives. '
 'The numerical searches used31.211676 CPU seconds combined; combined saved-output/source QA used3.955581 CPU seconds. '
 'No paid resources were used.\n')
(DEST/'REPORT.txt').write_text(text)
print(json.dumps({'status':summary['status'],'counts':summary['verified_counts'],'bandwidth_Hz':summary['new_carrier_edge_bandwidth_per_ON_Hz']}))
