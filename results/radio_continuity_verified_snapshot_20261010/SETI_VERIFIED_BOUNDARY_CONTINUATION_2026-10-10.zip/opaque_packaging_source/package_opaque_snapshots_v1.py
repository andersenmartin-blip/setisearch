"""Preserve already-produced files as opaque bytes; no scientific imports or HTTP."""
from pathlib import Path
import argparse, hashlib, json, os, resource, signal, time, zipfile, zlib

WORK = Path('/workspace/scratch/a8d1e29996d0/seti_fullpower_work')
OTHER = Path('/workspace/scratch/5bf3860dacd6/analysis')

def pin(p):
    h = hashlib.sha256(); n = 0
    with p.open('rb') as f:
        for b in iter(lambda: f.read(1048576), b''):
            h.update(b); n += len(b)
    return {'sha256': h.hexdigest(), 'bytes': n}

def save(p, value):
    with p.open('x') as f:
        json.dump(value, f, indent=2, sort_keys=True, allow_nan=False)
        f.write('\n'); f.flush(); os.fsync(f.fileno())

def main():
    started = time.monotonic()
    a = argparse.ArgumentParser(description=__doc__)
    a.add_argument('--kind', choices=['continuation', 'failed2017'], required=True)
    args = a.parse_args()
    def stop(*unused): raise TimeoutError('Opaque package resource cap')
    signal.signal(signal.SIGALRM, stop); signal.signal(signal.SIGXCPU, stop)
    signal.alarm(300); resource.setrlimit(resource.RLIMIT_CPU, (20, 21))
    resource.setrlimit(resource.RLIMIT_AS, (1024**3, 1024**3))
    if args.kind == 'continuation':
        source = WORK/'verified_continuation_snapshot'
        archive = WORK/'SETI_VERIFIED_BOUNDARY_CONTINUATION_2026-10-10.zip'
        selected = [(p, p.relative_to(source).as_posix()) for p in source.rglob('*') if p.is_file()]
        scientific_status = 'TWO_EXISTING_COMPLETE_CONTINUATIONS_WITH_EXISTING_SAVED_SOURCE_QA'
    else:
        source = OTHER
        archive = WORK/'SETI_S2017_FAILED_PARTIAL_SOURCE_2026-10-10.zip'
        names = ['new_visit_search/driver.py', 'new_visit_search/scope.json',
                 'new_visit_search/PUBLIC_FREEZE.json', 'new_visit_search/PUBLIC_FREEZE_READBACK.json',
                 'new_visit_search/ROOT_ACQUISITION_GO.json', 'new_visit_search/PROSPECTIVE_REVIEW.json',
                 'next_visit/S2017_MIDPOINT_SOURCE_MANIFEST.json',
                 'next_visit/METADATA_QUALIFICATION_RECEIPT.json',
                 'next_visit/DIRECT_MAPPING_INDEPENDENT_AUDIT.json',
                 'new_visit_search/results/acquire/ACQUISITION_RESULT.json',
                 'new_visit_search/results/acquire/FAILURE_RECEIPT.json',
                 'new_visit_search/results/acquire/INPUT_PINS.json',
                 'new_visit_search/results/acquire/SOURCE_BODY_LEDGER.json']
        names += ['new_visit_search/results/acquire/'+s+'.compact.h5' for s in
                  ['epoch1_on','epoch1_off','epoch2_on','epoch2_off','epoch3_on','epoch3_off']]
        selected = [(source/n, n) for n in names]
        scientific_status = 'INCOMPLETE_ORIGINAL_ACQUISITION_UNCHANGED_NO_SEARCH'
    selected.sort(key=lambda x: x[1])
    marker = archive.with_suffix('.STARTED.json')
    receipt = archive.with_suffix('.INTEGRITY.json')
    assert not any(p.exists() for p in (archive, marker, receipt)), 'Preserve existing outputs'
    save(marker, {'status': 'OPAQUE_PACKAGE_STARTED', 'kind': args.kind})
    pins = {}
    for p, n in selected:
        assert p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(source.resolve())
        assert '..' not in Path(n).parts and not Path(n).is_absolute()
        pins[n] = pin(p)
    manifest = {'schema': 'SETI_OPAQUE_EXISTING_BYTES_MANIFEST_V1', 'kind': args.kind,
                'original_scientific_status': scientific_status, 'file_pins': pins,
                'new_scientific_computations': 0, 'new_telescope_requests': 0,
                'HDF5_or_NPZ_arrays_opened': False,
                'failed_raw_physical_bytes_preserved_without_claim_of_valid_chunk_admission': args.kind == 'failed2017'}
    manifest_raw = (json.dumps(manifest, indent=2, sort_keys=True)+'\n').encode()
    allpins = {**pins, 'OPAQUE_BYTE_MANIFEST.json': {'sha256': hashlib.sha256(manifest_raw).hexdigest(), 'bytes': len(manifest_raw)}}
    with archive.open('xb') as dst:
        with zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED, compresslevel=1, allowZip64=True) as z:
            for p, n in selected:
                zi = zipfile.ZipInfo(n, (2026,10,10,0,0,0)); zi.compress_type = zipfile.ZIP_DEFLATED
                zi._compresslevel = 1; zi.external_attr = 0o100644 << 16
                with p.open('rb') as src, z.open(zi, 'w') as out:
                    for b in iter(lambda: src.read(1048576), b''): out.write(b)
            z.writestr('OPAQUE_BYTE_MANIFEST.json', manifest_raw)
        dst.flush(); os.fsync(dst.fileno())
    crcs = {}
    with zipfile.ZipFile(archive) as z:
        assert len(z.namelist()) == len(allpins) and set(z.namelist()) == set(allpins)
        for n in sorted(allpins):
            h = hashlib.sha256(); count = crc = 0
            with z.open(n) as f:
                for b in iter(lambda: f.read(1048576), b''):
                    h.update(b); count += len(b); crc = zlib.crc32(b, crc)
            assert {'sha256': h.hexdigest(), 'bytes': count} == allpins[n], n
            assert crc == z.getinfo(n).CRC, n
            crcs[n] = f'{crc:08x}'
    assert {n: pin(p) for p,n in selected} == pins, 'Source snapshot changed'
    ap = pin(archive); gh = hashlib.sha1(b'blob '+str(ap['bytes']).encode()+b'\0')
    with archive.open('rb') as f:
        for b in iter(lambda: f.read(1048576), b''): gh.update(b)
    elapsed = time.process_time()
    assert elapsed <= 20 and time.monotonic()-started <= 300
    result = {'schema': 'SETI_OPAQUE_ARCHIVE_INTEGRITY_V1', 'status': 'PASS_ALL_MEMBER_SHA256_SIZES_CRC_AND_UNCHANGED_SOURCE_SNAPSHOT',
              'kind': args.kind, 'archive': {'name': archive.name, **ap, 'git_blob_sha1': gh.hexdigest()},
              'member_count': len(allpins), 'member_pins': allpins, 'member_crc32': crcs,
              'original_scientific_status': scientific_status,
              'new_numerical_runs': 0, 'new_source_requests': 0, 'scientific_arrays_opened': False,
              'cost_DKK': 0, 'CPU_cap_s': 20, 'wall_cap_s': 300, 'memory_cap_bytes': 1024**3,
              'process_CPU_seconds_including_imports': elapsed, 'wall_seconds': time.monotonic()-started,
              'peak_RSS_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024}
    save(receipt, result); signal.alarm(0)
    print(json.dumps({k: result[k] for k in ['status','kind','archive','member_count','process_CPU_seconds_including_imports']}), flush=True)

if __name__ == '__main__': main()
