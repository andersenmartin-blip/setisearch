# SETI-radio: rapportkit 9. oktober 2026

Start med [rapporten](RADIO_REPORT_PACKAGE_2026-10-09.md) og [vejledningen](results/radio_report_package_20261009/KIT_GUIDE.md).

sha256sum -c SHA256SUMS kontrollerer transportintegritet. Udpakning starter ingen analyse. Scorekort/casearkiver er eksterne; pakken indeholder metadata og seks originale PDF-figurer.
