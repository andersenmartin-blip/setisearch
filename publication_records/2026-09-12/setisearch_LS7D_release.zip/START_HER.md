# SETI: LS7D er gennemført, offentliggørelse afventer

Vi har målt en konkret begrænsning i TESS-pixeltesten: modsat rettede
pixeludsving ophæver delvist hinanden, når lyset summeres. Den nuværende
støjmodel tager ikke højde for dette. De arkiverede pixelfejl bidrager
højst 0,0083 % til den tidligere målte støjforskel.

Alle 120 henvisninger til oprindelige prøvesignaler er kontrolleret.
De dækker 34 forskellige vinduer på ti baggrunde. Otte analytiske tests
og kontrollen af 68 kovariansmatricer bestod. Ingen ny kandidat er fundet,
og ingen ændret detektor er godkendt af de videnskabelige tests.

Læs `science/results_ls7d_noise/REPORT.md`, og se
`science/results_ls7d_noise/noise_accounting.png`. Den tidligere afsluttede
LS7C-test på sektor 32 er med i `science/results_ls7c_tess/`.

Automatisk godkendelseskontrol afviste offentliggørelse af den nye rapport,
fordi den krævede udtrykkelig tilladelse til dette materiale på det offentlige
GitHub-repository, selv om projektets løbende tilladelse var dokumenteret.
Ingen offentliggørelse lykkedes i dette arbejdstrin.

Pakken er klar til godkendelse af alle medfølgende LS7C-sektor-32- og LS7D-filer
til `andersenmartin-blip/setisearch` på `m43-support-qualification`, samt
README-opdateringen på `main`. Filer, hashes og præcise commits findes i
`publication_manifest.json`. Det er offentlig deling af de afledte resultater.

Git-bundles bevarer de lokale commits relativt til de angivne offentlige
udgangspunkter. Kontroller de aktuelle GitHub-grene inden udgivelse, og
bevar senere arbejde. Forsøget på sektor 29, der også hed LS7C, er separat;
det ligger ikke i denne pakke. Se fortsættelses- og udgivelsesnoterne i `science/`.

Næste videnskabelige trin er en samlet udviklingstest af en bedre støjmodel,
uvedkommende pixelrester og flere typer instrumentel forurening på allerede
analyserede data. Der er ikke åbnet en ny TESS-sektor i dette trin.
